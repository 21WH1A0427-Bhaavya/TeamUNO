# Cybersecurity Monitoring Dashboard

## Overview

This is a comprehensive cybersecurity monitoring dashboard built as a full-stack web application. The system provides real-time security monitoring, anomaly detection, and risk assessment capabilities for enterprise environments. It features a modern dark-themed interface optimized for security operations centers, with comprehensive dashboards for monitoring user sessions, detecting security anomalies, managing alerts, and analyzing security metrics.

The application includes machine learning capabilities for anomaly detection (using autoencoder models), real-time monitoring of network activity and user behavior, and detailed analytics for security risk assessment across departments and device types.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development/build tooling
- **UI Framework**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom cybersecurity-focused dark theme
- **State Management**: TanStack Query for server state and caching
- **Routing**: Wouter for lightweight client-side routing
- **Design System**: Custom design guidelines focused on cybersecurity monitoring with matrix-green color scheme and monospace fonts

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API architecture with /api prefix routing
- **Development**: Hot reload development server with Vite integration
- **Error Handling**: Centralized error handling middleware with structured responses

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple
- **Development Storage**: In-memory storage implementation for development/testing

### Authentication and Authorization
- **Session Management**: Express session-based authentication
- **User Schema**: Basic user model with username/password authentication
- **Development Mode**: Mock storage implementation for rapid development

### Machine Learning Integration
- **Anomaly Detection**: Python-based autoencoder model for behavioral anomaly detection
- **Risk Scoring**: Multi-factor risk assessment system combining session behavior, device types, and access patterns
- **Data Processing**: Real-time processing of user activity metrics including file access, download patterns, and session duration

### UI Component Architecture
- **Component Library**: Comprehensive set of reusable components (cards, charts, tables, forms)
- **Dashboard Layout**: Responsive sidebar navigation with collapsible panels
- **Real-time Updates**: Live monitoring components with simulated real-time data feeds
- **Accessibility**: Full keyboard navigation and screen reader support through Radix UI

## External Dependencies

### Core Framework Dependencies
- **@radix-ui/react-***: Complete suite of accessible UI primitives for complex components
- **@tanstack/react-query**: Server state management and caching
- **drizzle-orm**: Type-safe ORM for PostgreSQL operations
- **express**: Web application framework for API server

### Database and Storage
- **@neondatabase/serverless**: Serverless PostgreSQL database driver
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **drizzle-kit**: Database migration and schema management tools

### Development and Build Tools
- **vite**: Modern build tool and development server
- **@vitejs/plugin-react**: React plugin for Vite
- **esbuild**: Fast JavaScript bundler for production builds
- **tsx**: TypeScript execution engine for development

### UI and Styling
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe component variant API
- **lucide-react**: Modern icon library
- **embla-carousel-react**: Carousel component for data visualization

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **wouter**: Lightweight routing library
- **clsx**: Conditional CSS class utility
- **nanoid**: Unique ID generation

### Development Environment
- **@replit/vite-plugin-***: Replit-specific development tools and error handling
- **postcss**: CSS post-processing for Tailwind CSS