import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Switch, Route } from "wouter";
import DashboardSidebar from './DashboardSidebar';
import DashboardHeader from './DashboardHeader';
import DashboardHome from '@/pages/DashboardHome';
import LiveMonitoring from '@/pages/LiveMonitoring';
import UserSessions from '@/pages/UserSessions';
import AlertsPage from '@/pages/AlertsPage';
import Analytics from '@/pages/Analytics';
import Settings from '@/pages/Settings';


function Router() {
  return (
    <Switch>
      <Route path="/" component={DashboardHome} />
      <Route path="/monitoring" component={LiveMonitoring} />
      <Route path="/users" component={UserSessions} />
      <Route path="/alerts" component={AlertsPage} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/settings" component={Settings} />
    </Switch>
  );
}

export default function Dashboard() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background">
        <DashboardSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <div className="flex items-center gap-2 p-2 border-b border-border">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </div>
          
          <DashboardHeader />
          
          <main className="flex-1 overflow-y-auto">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}