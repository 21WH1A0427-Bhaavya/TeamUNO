import Dashboard from '../Dashboard';

export default function DashboardExample() {
  return (
    <div className="h-screen w-full">
      <Dashboard />
    </div>
  );
}