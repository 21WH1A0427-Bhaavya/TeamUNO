import MetricsCard from '../MetricsCard';
import { Users, AlertTriangle, Shield, Activity } from 'lucide-react';

export default function MetricsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <MetricsCard
        title="Active Sessions"
        value={147}
        trend={{ value: "12%", isUp: true }}
        icon={Users}
      />
      <MetricsCard
        title="Anomalies Detected"
        value={23}
        trend={{ value: "5%", isUp: true }}
        icon={AlertTriangle}
        alert
      />
      <MetricsCard
        title="Risk Score"
        value={"Medium"}
        icon={Shield}
      />
      <MetricsCard
        title="System Health"
        value={"98.5%"}
        trend={{ value: "0.2%", isUp: false }}
        icon={Activity}
      />
    </div>
  );
}