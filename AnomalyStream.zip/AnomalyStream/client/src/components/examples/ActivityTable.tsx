import ActivityTable from '../ActivityTable';

// Todo: remove mock data when integrating with real backend
const mockActivities = [
  {
    user_id: 'user_00080',
    department: 'Sales',
    session_minutes: 37,
    device_type: 'Windows-PC',
    location_country: 'Singapore',
    anomaly_score: 0.344,
    is_anomaly: true,
    anomaly_type: 'mass_download',
    risk_score: 12,
    timestamp: '08:11:00'
  },
  {
    user_id: 'user_00085',
    department: 'IT',
    session_minutes: 95,
    device_type: 'Windows-PC',
    location_country: 'India',
    anomaly_score: 0.249,
    is_anomaly: true,
    anomaly_type: 'no_mfa_privileged_action',
    risk_score: 16,
    timestamp: '08:27:00'
  },
  {
    user_id: 'user_00030',
    department: 'HR',
    session_minutes: 17,
    device_type: 'Windows-PC',
    location_country: 'India',
    anomaly_score: 0.128,
    is_anomaly: true,
    anomaly_type: 'suspicious_app_usage',
    risk_score: 5,
    timestamp: '08:34:00'
  },
  {
    user_id: 'user_00051',
    department: 'Finance',
    session_minutes: 33,
    device_type: 'MacBook',
    location_country: 'Singapore',
    anomaly_score: 0.202,
    is_anomaly: false,
    risk_score: 13,
    timestamp: '08:35:00'
  },
  {
    user_id: 'user_00004',
    department: 'IT',
    session_minutes: 101,
    device_type: 'Windows-PC',
    location_country: 'Singapore',
    anomaly_score: 0.11,
    is_anomaly: false,
    risk_score: 5,
    timestamp: '08:42:00'
  }
];

export default function ActivityTableExample() {
  return <ActivityTable activities={mockActivities} />;
}