import AlertPanel from '../AlertPanel';

const mockAlerts = [
  {
    id: '1',
    type: 'mass_download',
    user: 'user_00080',
    message: 'Unusual mass download activity detected from Sales department',
    priority: 'High' as const,
    timestamp: '08:11:00'
  },
  {
    id: '2', 
    type: 'no_mfa_privileged_action',
    user: 'user_00085',
    message: 'Privileged action performed without MFA verification',
    priority: 'Medium' as const,
    timestamp: '08:27:00'
  },
  {
    id: '3',
    type: 'suspicious_app_usage',
    user: 'user_00030',
    message: 'Suspicious application usage pattern detected',
    priority: 'Low' as const,
    timestamp: '08:34:00'
  }
];

export default function AlertPanelExample() {
  return <AlertPanel alerts={mockAlerts} />;
}