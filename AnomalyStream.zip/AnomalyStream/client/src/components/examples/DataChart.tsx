import DataChart from '../DataChart';

// Todo: remove mock data when integrating with real backend
const departmentRiskData = [
  { label: 'Sales', value: 23 },
  { label: 'IT', value: 18 },
  { label: 'HR', value: 15 },
  { label: 'Finance', value: 12 },
  { label: 'R&D', value: 8 }
];

const anomalyTypeData = [
  { label: 'Mass Download', value: 12 },
  { label: 'No MFA', value: 8 },
  { label: 'Suspicious App Usage', value: 6 },
  { label: 'Unusual Hours', value: 4 },
  { label: 'Geo Risk', value: 3 }
];

export default function DataChartExample() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <DataChart 
        title="Risk by Department" 
        data={departmentRiskData}
      />
      <DataChart 
        title="Anomaly Types" 
        data={anomalyTypeData}
      />
    </div>
  );
}