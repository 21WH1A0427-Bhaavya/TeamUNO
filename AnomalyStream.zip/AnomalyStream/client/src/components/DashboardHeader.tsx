import { Bell, Shield, Search, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export default function DashboardHeader() {
  return (
    <header className="flex items-center justify-between p-6 border-b border-border bg-background">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Shield className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground font-mono">CyberWatch</h1>
            <p className="text-sm text-muted-foreground">Real-time Security Monitor</p>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search users, sessions..." 
            className="pl-10 w-80 bg-card border-card-border"
            data-testid="input-search"
          />
        </div>
        
        <Button variant="outline" size="icon" data-testid="button-filter">
          <Filter className="w-4 h-4" />
        </Button>
        
        <div className="relative">
          <Button variant="outline" size="icon" className="animate-pulse-green" data-testid="button-alerts">
            <Bell className="w-4 h-4" />
          </Button>
          <Badge className="absolute -top-2 -right-2 bg-destructive text-xs px-1 min-w-5 h-5">3</Badge>
        </div>
        
        <div className="flex items-center gap-2 pl-4 border-l border-border">
          <div className="w-2 h-2 bg-primary rounded-full animate-pulse-green"></div>
          <span className="text-sm text-muted-foreground font-mono">System Online</span>
        </div>
      </div>
    </header>
  );
}