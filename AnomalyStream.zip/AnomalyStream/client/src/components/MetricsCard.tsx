import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface MetricsCardProps {
  title: string;
  value: string | number;
  trend?: {
    value: string;
    isUp: boolean;
  };
  icon: LucideIcon;
  className?: string;
  alert?: boolean;
}

export default function MetricsCard({ title, value, trend, icon: Icon, className, alert }: MetricsCardProps) {
  return (
    <Card className={`hover-elevate transition-all duration-300 ${alert ? 'border-destructive/50 bg-destructive/5' : ''} ${className}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-card-foreground">{title}</CardTitle>
        <Icon className={`w-4 h-4 ${alert ? 'text-destructive' : 'text-primary'}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold font-mono text-card-foreground">{value}</div>
        {trend && (
          <Badge 
            variant={trend.isUp ? "destructive" : "default"} 
            className="mt-2 text-xs"
          >
            {trend.isUp ? '↑' : '↓'} {trend.value}
          </Badge>
        )}
      </CardContent>
    </Card>
  );
}