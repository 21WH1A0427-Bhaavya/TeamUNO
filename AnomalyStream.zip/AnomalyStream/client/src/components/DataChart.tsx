import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, BarChart3 } from "lucide-react";
import { useState, useEffect } from "react";

interface ChartData {
  label: string;
  value: number;
  color?: string;
}

interface DataChartProps {
  title: string;
  data: ChartData[];
  type?: 'bar' | 'line';
  className?: string;
}

export default function DataChart({ title, data, type = 'bar', className }: DataChartProps) {
  const [animatedData, setAnimatedData] = useState(data.map(d => ({ ...d, value: 0 })));
  const maxValue = Math.max(...data.map(d => d.value));

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedData(data);
    }, 100);
    return () => clearTimeout(timer);
  }, [data]);

  return (
    <Card className={`animate-fade-in hover-elevate transition-all duration-300 ${className}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />
          {title}
          <Badge className="bg-primary text-primary-foreground font-mono">
            {data.length} Items
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {animatedData.map((item, index) => {
            const percentage = maxValue > 0 ? (item.value / maxValue) * 100 : 0;
            return (
              <div key={item.label} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-mono text-card-foreground">{item.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-primary font-mono">{item.value}</span>
                    <TrendingUp className="w-3 h-3 text-primary" />
                  </div>
                </div>
                <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="absolute left-0 top-0 h-full bg-gradient-to-r from-primary to-chart-1 rounded-full transition-all duration-1000 ease-out animate-glow"
                    style={{ 
                      width: `${percentage}%`,
                      animationDelay: `${index * 200}ms`
                    }}
                    data-testid={`chart-bar-${item.label.replace(/\s+/g, '-').toLowerCase()}`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}