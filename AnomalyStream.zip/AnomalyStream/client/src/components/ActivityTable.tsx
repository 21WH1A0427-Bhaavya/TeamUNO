import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, AlertTriangle, Shield, Laptop, Smartphone, Server } from "lucide-react";

interface UserActivity {
  user_id: string;
  department: string;
  session_minutes: number;
  device_type: string;
  location_country: string;
  anomaly_score: number;
  is_anomaly: boolean;
  anomaly_type?: string;
  risk_score: number;
  timestamp: string;
}

interface ActivityTableProps {
  activities: UserActivity[];
}

const getDeviceIcon = (deviceType: string) => {
  switch (deviceType) {
    case 'Windows-PC': case 'MacBook': return Laptop;
    case 'Mobile': return Smartphone;
    case 'Linux-Server': case 'VDI': return Server;
    default: return Laptop;
  }
};

const getRiskColor = (score: number) => {
  if (score >= 25) return 'destructive';
  if (score >= 15) return 'secondary';
  return 'outline';
};

export default function ActivityTable({ activities }: ActivityTableProps) {
  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          Recent Activity
          <Badge className="bg-primary text-primary-foreground font-mono">
            {activities.length} Sessions
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">User</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Department</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Device</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Location</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Duration</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Risk</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Status</th>
                <th className="text-left p-3 font-mono text-sm text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {activities.map((activity, index) => {
                const DeviceIcon = getDeviceIcon(activity.device_type);
                return (
                  <tr 
                    key={`${activity.user_id}-${activity.timestamp}`}
                    className={`border-b border-border hover-elevate transition-all duration-300 animate-slide-up ${
                      activity.is_anomaly ? 'bg-destructive/5' : ''
                    }`}
                    style={{ animationDelay: `${index * 50}ms` }}
                    data-testid={`activity-row-${activity.user_id}`}
                  >
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        {activity.is_anomaly && (
                          <AlertTriangle className="w-4 h-4 text-destructive" />
                        )}
                        <span className="font-mono text-sm text-card-foreground">{activity.user_id}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge variant="outline" className="font-mono text-xs">
                        {activity.department}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <DeviceIcon className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-card-foreground">{activity.device_type}</span>
                      </div>
                    </td>
                    <td className="p-3 text-sm text-card-foreground">{activity.location_country}</td>
                    <td className="p-3 font-mono text-sm text-card-foreground">{activity.session_minutes}m</td>
                    <td className="p-3">
                      <Badge variant={getRiskColor(activity.risk_score) as any} className="font-mono text-xs">
                        {activity.risk_score}
                      </Badge>
                    </td>
                    <td className="p-3">
                      {activity.is_anomaly ? (
                        <Badge variant="destructive" className="text-xs">
                          {activity.anomaly_type || 'Anomaly'}
                        </Badge>
                      ) : (
                        <Badge variant="default" className="text-xs">Normal</Badge>
                      )}
                    </td>
                    <td className="p-3">
                      <Button variant="ghost" size="icon" className="w-6 h-6" data-testid={`button-view-${activity.user_id}`}>
                        <Eye className="w-3 h-3" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}