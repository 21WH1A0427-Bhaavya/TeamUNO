import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X, Eye } from "lucide-react";

interface Alert {
  id: string;
  type: string;
  user: string;
  message: string;
  priority: 'High' | 'Medium' | 'Low';
  timestamp: string;
}

interface AlertPanelProps {
  alerts: Alert[];
}

export default function AlertPanel({ alerts }: AlertPanelProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
      default: return 'outline';
    }
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-primary" />
          Real-time Alerts
          <Badge className="bg-destructive text-destructive-foreground">{alerts.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {alerts.map((alert, index) => (
            <div 
              key={alert.id} 
              className="flex items-start gap-3 p-3 bg-card border border-card-border rounded-lg hover-elevate animate-slide-up"
              style={{ animationDelay: `${index * 100}ms` }}
              data-testid={`alert-${alert.id}`}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant={getPriorityColor(alert.priority) as any}>
                    {alert.priority}
                  </Badge>
                  <span className="text-xs text-muted-foreground font-mono">{alert.type}</span>
                  <span className="text-xs text-muted-foreground">{alert.timestamp}</span>
                </div>
                <p className="text-sm text-card-foreground">{alert.message}</p>
                <p className="text-xs text-primary font-mono mt-1">User: {alert.user}</p>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="w-6 h-6" data-testid={`button-view-${alert.id}`}>
                  <Eye className="w-3 h-3" />
                </Button>
                <Button variant="ghost" size="icon" className="w-6 h-6" data-testid={`button-dismiss-${alert.id}`}>
                  <X className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}