import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Search, Eye, X, Clock, User, CheckCircle, XCircle, Bell, Filter } from 'lucide-react';

interface Alert {
  id: string;
  type: string;
  user_id: string;
  message: string;
  priority: 'High' | 'Medium' | 'Low';
  timestamp: string;
  status: 'active' | 'acknowledged' | 'resolved' | 'dismissed';
  department: string;
  risk_score: number;
  details?: string;
}

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filteredAlerts, setFilteredAlerts] = useState<Alert[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  // Initialize with alert data
  useEffect(() => {
    const initialAlerts: Alert[] = [
      {
        id: '1',
        type: 'mass_download',
        user_id: 'user_00080',
        message: 'Unusual mass download activity detected from Sales department',
        priority: 'High',
        timestamp: '08:11:00',
        status: 'active',
        department: 'Sales',
        risk_score: 12,
        details: 'User downloaded 7 files totaling 315KB in 37 minutes from SQL client'
      },
      {
        id: '2',
        type: 'no_mfa_privileged_action',
        user_id: 'user_00085',
        message: 'Privileged action performed without MFA verification',
        priority: 'High',
        timestamp: '08:27:00',
        status: 'acknowledged',
        department: 'IT',
        risk_score: 16,
        details: 'File explorer access from external IP without multi-factor authentication'
      },
      {
        id: '3',
        type: 'suspicious_app_usage',
        user_id: 'user_00030',
        message: 'Suspicious application usage pattern detected',
        priority: 'Medium',
        timestamp: '08:34:00',
        status: 'resolved',
        department: 'HR',
        risk_score: 5,
        details: 'Email application accessed outside normal business hours'
      },
      {
        id: '4',
        type: 'geo_risk',
        user_id: 'user_00051',
        message: 'Login from unusual geographic location',
        priority: 'Medium',
        timestamp: '08:35:00',
        status: 'active',
        department: 'Finance',
        risk_score: 13,
        details: 'User logged in from Singapore, typical location is India'
      },
      {
        id: '5',
        type: 'unusual_hours',
        user_id: 'user_00004',
        message: 'Access outside normal business hours',
        priority: 'Low',
        timestamp: '08:42:00',
        status: 'dismissed',
        department: 'IT',
        risk_score: 5,
        details: 'File explorer access at 08:42, outside standard 09:00-17:00 hours'
      },
      {
        id: '6',
        type: 'failed_login_attempts',
        user_id: 'user_00099',
        message: 'Multiple failed login attempts detected',
        priority: 'High',
        timestamp: '09:15:00',
        status: 'active',
        department: 'Finance',
        risk_score: 20,
        details: '5 consecutive failed login attempts from different IP addresses'
      },
      {
        id: '7',
        type: 'data_exfiltration',
        user_id: 'user_00117',
        message: 'Potential data exfiltration detected',
        priority: 'High',
        timestamp: '09:22:00',
        status: 'active',
        department: 'Sales',
        risk_score: 25,
        details: 'Large file transfers to external servers during off-hours'
      },
      {
        id: '8',
        type: 'privilege_escalation',
        user_id: 'user_00067',
        message: 'Unauthorized privilege escalation attempt',
        priority: 'Medium',
        timestamp: '09:28:00',
        status: 'acknowledged',
        department: 'IT',
        risk_score: 14,
        details: 'Developer account attempted to access admin-level resources'
      }
    ];
    setAlerts(initialAlerts);
    setFilteredAlerts(initialAlerts);
  }, []);

  // Filter alerts
  useEffect(() => {
    let filtered = alerts;

    if (searchTerm) {
      filtered = filtered.filter(alert => 
        alert.user_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.type.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (priorityFilter !== 'all') {
      filtered = filtered.filter(alert => alert.priority === priorityFilter);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(alert => alert.status === statusFilter);
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter(alert => alert.type === typeFilter);
    }

    setFilteredAlerts(filtered);
  }, [alerts, searchTerm, priorityFilter, statusFilter, typeFilter]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'destructive';
      case 'acknowledged': return 'secondary';
      case 'resolved': return 'default';
      case 'dismissed': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return AlertTriangle;
      case 'acknowledged': return Eye;
      case 'resolved': return CheckCircle;
      case 'dismissed': return XCircle;
      default: return AlertTriangle;
    }
  };

  const updateAlertStatus = (alertId: string, newStatus: Alert['status']) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, status: newStatus } : alert
    ));
  };

  const acknowledgeAlert = (alertId: string) => {
    updateAlertStatus(alertId, 'acknowledged');
  };

  const resolveAlert = (alertId: string) => {
    updateAlertStatus(alertId, 'resolved');
  };

  const dismissAlert = (alertId: string) => {
    updateAlertStatus(alertId, 'dismissed');
  };

  const activeCount = alerts.filter(a => a.status === 'active').length;
  const highPriorityCount = alerts.filter(a => a.priority === 'High' && a.status === 'active').length;
  const alertTypes = Array.from(new Set(alerts.map(a => a.type)));

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-mono">Security Alerts</h1>
          <p className="text-muted-foreground">Monitor and manage security incidents</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="destructive" className="font-mono animate-pulse-green">
            {activeCount} Active
          </Badge>
          <Badge variant="destructive" className="font-mono">
            {highPriorityCount} High Priority
          </Badge>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
            <Bell className="w-4 h-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive">{activeCount}</div>
            <Badge variant="destructive" className="mt-2 text-xs">Critical</Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Priority</CardTitle>
            <AlertTriangle className="w-4 h-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive">{highPriorityCount}</div>
            <Badge variant="destructive" className="mt-2 text-xs">Urgent</Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Acknowledged</CardTitle>
            <Eye className="w-4 h-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-secondary">
              {alerts.filter(a => a.status === 'acknowledged').length}
            </div>
            <Badge variant="secondary" className="mt-2 text-xs">In Review</Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resolved</CardTitle>
            <CheckCircle className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-primary">
              {alerts.filter(a => a.status === 'resolved').length}
            </div>
            <Badge className="mt-2 text-xs bg-primary text-primary-foreground">Completed</Badge>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search alerts, users, messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-alert-search"
              />
            </div>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-32" data-testid="select-priority-filter">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36" data-testid="select-status-filter">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="acknowledged">Acknowledged</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="dismissed">Dismissed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-40" data-testid="select-type-filter">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {alertTypes.map(type => (
                  <SelectItem key={type} value={type}>
                    {type.replace('_', ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-primary" />
            Security Alerts
            <Badge className="bg-primary text-primary-foreground font-mono">
              {filteredAlerts.length} Results
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredAlerts.map((alert, index) => {
              const StatusIcon = getStatusIcon(alert.status);
              return (
                <div
                  key={alert.id}
                  className={`p-4 border rounded-lg hover-elevate animate-slide-up transition-all ${
                    alert.status === 'active' ? 'border-destructive/50 bg-destructive/5' : 'border-card-border'
                  }`}
                  style={{ animationDelay: `${index * 50}ms` }}
                  data-testid={`alert-${alert.id}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <StatusIcon className={`w-4 h-4 ${
                          alert.status === 'active' ? 'text-destructive' : 'text-muted-foreground'
                        }`} />
                        <Badge variant={getPriorityColor(alert.priority) as any} className="text-xs">
                          {alert.priority}
                        </Badge>
                        <Badge variant={getStatusColor(alert.status) as any} className="text-xs">
                          {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                        </Badge>
                        <Badge variant="outline" className="text-xs font-mono">
                          {alert.type.replace('_', ' ')}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{alert.timestamp}</span>
                      </div>
                      
                      <h3 className="font-semibold text-card-foreground">{alert.message}</h3>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          <span className="font-mono">{alert.user_id}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span>Department: {alert.department}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span>Risk Score: </span>
                          <span className="font-mono text-primary">{alert.risk_score}</span>
                        </div>
                      </div>
                      
                      {alert.details && (
                        <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded border-l-2 border-primary">
                          {alert.details}
                        </p>
                      )}
                    </div>

                    <div className="flex gap-2 ml-4">
                      <Button variant="ghost" size="icon" className="w-8 h-8" data-testid={`button-view-${alert.id}`}>
                        <Eye className="w-4 h-4" />
                      </Button>
                      {alert.status === 'active' && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => acknowledgeAlert(alert.id)}
                            className="text-xs"
                            data-testid={`button-acknowledge-${alert.id}`}
                          >
                            Acknowledge
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => resolveAlert(alert.id)}
                            className="text-xs text-primary hover:text-primary"
                            data-testid={`button-resolve-${alert.id}`}
                          >
                            Resolve
                          </Button>
                        </>
                      )}
                      {alert.status !== 'dismissed' && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => dismissAlert(alert.id)}
                          className="w-8 h-8 text-muted-foreground hover:text-destructive"
                          data-testid={`button-dismiss-${alert.id}`}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            {filteredAlerts.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No alerts match your current filters.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}