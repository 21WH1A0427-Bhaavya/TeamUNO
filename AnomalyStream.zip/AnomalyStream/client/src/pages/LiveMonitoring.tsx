import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Activity, Wifi, Users, AlertTriangle, Play, Pause, RefreshCw } from 'lucide-react';

interface NetworkActivity {
  timestamp: string;
  source: string;
  destination: string;
  protocol: string;
  bytes: number;
  threat_level: 'Low' | 'Medium' | 'High';
}

interface LiveSession {
  user_id: string;
  location: string;
  activity: string;
  risk_level: number;
  last_action: string;
}

export default function LiveMonitoring() {
  const [isMonitoring, setIsMonitoring] = useState(true);
  const [networkTraffic, setNetworkTraffic] = useState<NetworkActivity[]>([]);
  const [liveSessions, setLiveSessions] = useState<LiveSession[]>([]);
  const [threatAlerts, setThreatAlerts] = useState(0);
  const [activeConnections, setActiveConnections] = useState(0);
  const [dataTransfer, setDataTransfer] = useState(0);

  // Simulate real-time data updates
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(() => {
      // Add new network activity
      const newActivity: NetworkActivity = {
        timestamp: new Date().toLocaleTimeString(),
        source: `192.168.1.${Math.floor(Math.random() * 255)}`,
        destination: `10.0.0.${Math.floor(Math.random() * 255)}`,
        protocol: ['HTTP', 'HTTPS', 'SSH', 'FTP'][Math.floor(Math.random() * 4)],
        bytes: Math.floor(Math.random() * 100000) + 1000,
        threat_level: ['Low', 'Medium', 'High'][Math.floor(Math.random() * 3)] as 'Low' | 'Medium' | 'High'
      };

      setNetworkTraffic(prev => [newActivity, ...prev.slice(0, 19)]);
      
      // Update live sessions
      setLiveSessions(prev => prev.map(session => ({
        ...session,
        last_action: new Date().toLocaleTimeString(),
        risk_level: Math.max(0, session.risk_level + (Math.random() - 0.5) * 2)
      })));

      // Update metrics
      setThreatAlerts(prev => prev + (Math.random() > 0.8 ? 1 : 0));
      setActiveConnections(prev => Math.max(0, prev + Math.floor(Math.random() * 6) - 3));
      setDataTransfer(prev => prev + Math.floor(Math.random() * 1000));
    }, 2000);

    return () => clearInterval(interval);
  }, [isMonitoring]);

  // Initialize data
  useEffect(() => {
    const initialSessions: LiveSession[] = [
      { user_id: 'user_00080', location: 'Singapore', activity: 'File Transfer', risk_level: 15, last_action: '09:15:23' },
      { user_id: 'user_00085', location: 'India', activity: 'Database Query', risk_level: 8, last_action: '09:14:55' },
      { user_id: 'user_00030', location: 'India', activity: 'Email Access', risk_level: 3, last_action: '09:13:12' },
      { user_id: 'user_00051', location: 'Singapore', activity: 'Web Browsing', risk_level: 5, last_action: '09:12:44' }
    ];
    
    setLiveSessions(initialSessions);
    setThreatAlerts(5);
    setActiveConnections(147);
    setDataTransfer(2847392);
  }, []);

  const getThreatColor = (level: string) => {
    switch (level) {
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
      default: return 'outline';
    }
  };

  const getRiskColor = (level: number) => {
    if (level >= 10) return 'destructive';
    if (level >= 5) return 'secondary';
    return 'outline';
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-mono">Live Monitoring</h1>
          <p className="text-muted-foreground">Real-time network and security monitoring</p>
        </div>
        <div className="flex items-center gap-4">
          <Button
            variant={isMonitoring ? 'destructive' : 'default'}
            onClick={() => setIsMonitoring(!isMonitoring)}
            className="flex items-center gap-2"
            data-testid="button-toggle-monitoring"
          >
            {isMonitoring ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isMonitoring ? 'Stop Monitoring' : 'Start Monitoring'}
          </Button>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isMonitoring ? 'bg-primary animate-pulse-green' : 'bg-muted'}`}></div>
            <span className="text-sm font-mono text-muted-foreground">
              {isMonitoring ? 'Live' : 'Stopped'}
            </span>
          </div>
        </div>
      </div>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Connections</CardTitle>
            <Wifi className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-primary">{activeConnections}</div>
            <Badge className="mt-2 bg-primary/20 text-primary border-primary/30">
              Real-time
            </Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Threat Alerts</CardTitle>
            <AlertTriangle className="w-4 h-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive">{threatAlerts}</div>
            <Badge variant="destructive" className="mt-2">
              Active
            </Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Live Sessions</CardTitle>
            <Users className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-primary">{liveSessions.length}</div>
            <Badge className="mt-2 bg-primary/20 text-primary border-primary/30">
              Monitoring
            </Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Data Transfer</CardTitle>
            <Activity className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-primary">
              {(dataTransfer / 1024 / 1024).toFixed(1)}MB
            </div>
            <Badge className="mt-2 bg-primary/20 text-primary border-primary/30">
              Flowing
            </Badge>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Network Traffic Monitor */}
        <Card className="animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Network Traffic
              <Badge className="bg-primary text-primary-foreground font-mono">
                Live Feed
              </Badge>
              {isMonitoring && <RefreshCw className="w-3 h-3 text-primary animate-spin" />}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {networkTraffic.map((activity, index) => (
                <div 
                  key={`${activity.timestamp}-${index}`}
                  className="flex items-center justify-between p-3 bg-card border border-card-border rounded-lg animate-slide-up hover-elevate"
                  style={{ animationDelay: `${index * 50}ms` }}
                  data-testid={`network-activity-${index}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={getThreatColor(activity.threat_level) as any} className="text-xs">
                        {activity.threat_level}
                      </Badge>
                      <span className="text-xs font-mono text-muted-foreground">{activity.protocol}</span>
                      <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                    </div>
                    <div className="text-sm text-card-foreground font-mono">
                      {activity.source} → {activity.destination}
                    </div>
                    <div className="text-xs text-primary font-mono">
                      {(activity.bytes / 1024).toFixed(1)}KB
                    </div>
                  </div>
                  <div className="w-2 h-8 bg-gradient-to-t from-primary/20 to-primary rounded animate-pulse"></div>
                </div>
              ))}
              {networkTraffic.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  {isMonitoring ? 'Waiting for network activity...' : 'Monitoring stopped'}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Live User Sessions */}
        <Card className="animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Live User Sessions
              <Badge className="bg-primary text-primary-foreground font-mono">
                {liveSessions.length} Active
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {liveSessions.map((session, index) => (
                <div 
                  key={session.user_id}
                  className="flex items-center justify-between p-3 bg-card border border-card-border rounded-lg animate-slide-up hover-elevate"
                  style={{ animationDelay: `${index * 100}ms` }}
                  data-testid={`live-session-${session.user_id}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                      <span className="font-mono text-sm text-card-foreground">{session.user_id}</span>
                      <Badge variant={getRiskColor(session.risk_level) as any} className="text-xs font-mono">
                        Risk: {session.risk_level.toFixed(0)}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {session.activity} • {session.location}
                    </div>
                    <div className="text-xs font-mono text-primary">
                      Last action: {session.last_action}
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="w-6 h-6" data-testid={`button-view-session-${session.user_id}`}>
                    <Activity className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}