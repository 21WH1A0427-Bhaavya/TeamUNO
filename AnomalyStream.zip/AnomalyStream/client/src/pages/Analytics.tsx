import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, TrendingUp, TrendingDown, Users, Shield, Activity, Download, Calendar } from 'lucide-react';

interface AnalyticsData {
  timeRange: string;
  totalSessions: number;
  anomalies: number;
  riskScore: number;
  departments: { name: string; sessions: number; risk: number; }[];
  timeSeriesData: { time: string; sessions: number; anomalies: number; risk: number; }[];
  topThreats: { type: string; count: number; trend: number; }[];
  deviceDistribution: { type: string; count: number; percentage: number; }[];
}

export default function Analytics() {
  const [timeRange, setTimeRange] = useState('24h');
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);

  // Generate analytics data based on time range
  useEffect(() => {
    const generateData = () => {
      const data: AnalyticsData = {
        timeRange,
        totalSessions: timeRange === '24h' ? 147 : timeRange === '7d' ? 1029 : 4217,
        anomalies: timeRange === '24h' ? 23 : timeRange === '7d' ? 156 : 634,
        riskScore: timeRange === '24h' ? 15.4 : timeRange === '7d' ? 18.2 : 16.8,
        departments: [
          { name: 'Sales', sessions: 45, risk: 23 },
          { name: 'IT', sessions: 38, risk: 18 },
          { name: 'HR', sessions: 28, risk: 15 },
          { name: 'Finance', sessions: 22, risk: 12 },
          { name: 'R&D', sessions: 14, risk: 8 }
        ],
        timeSeriesData: Array.from({ length: timeRange === '24h' ? 24 : timeRange === '7d' ? 7 : 30 }, (_, i) => ({
          time: timeRange === '24h' ? `${i}:00` : timeRange === '7d' ? `Day ${i + 1}` : `Week ${i + 1}`,
          sessions: Math.floor(Math.random() * 50) + 20,
          anomalies: Math.floor(Math.random() * 8) + 1,
          risk: Math.floor(Math.random() * 20) + 5
        })),
        topThreats: [
          { type: 'Mass Download', count: 12, trend: 15 },
          { type: 'No MFA', count: 8, trend: -3 },
          { type: 'Suspicious App Usage', count: 6, trend: 22 },
          { type: 'Unusual Hours', count: 4, trend: 8 },
          { type: 'Geo Risk', count: 3, trend: -12 }
        ],
        deviceDistribution: [
          { type: 'Windows-PC', count: 82, percentage: 56 },
          { type: 'MacBook', count: 35, percentage: 24 },
          { type: 'Mobile', count: 20, percentage: 14 },
          { type: 'Linux-Server', count: 10, percentage: 6 }
        ]
      };
      setAnalyticsData(data);
    };

    generateData();
  }, [timeRange]);

  if (!analyticsData) return <div>Loading analytics...</div>;

  const anomalyRate = ((analyticsData.anomalies / analyticsData.totalSessions) * 100).toFixed(1);
  const maxSessionDept = analyticsData.departments.reduce((prev, current) => 
    prev.sessions > current.sessions ? prev : current
  );
  const maxRiskDept = analyticsData.departments.reduce((prev, current) => 
    prev.risk > current.risk ? prev : current
  );

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-mono">Analytics</h1>
          <p className="text-muted-foreground">Advanced security analytics and insights</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32" data-testid="select-time-range">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="flex items-center gap-2" data-testid="button-export">
            <Download className="w-4 h-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sessions</CardTitle>
            <Users className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-primary">{analyticsData.totalSessions.toLocaleString()}</div>
            <Badge className="mt-2 bg-primary/20 text-primary border-primary/30 text-xs">
              {timeRange}
            </Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Anomaly Rate</CardTitle>
            <Shield className="w-4 h-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive">{anomalyRate}%</div>
            <Badge variant="destructive" className="mt-2 text-xs">
              {analyticsData.anomalies} anomalies
            </Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Risk Score</CardTitle>
            <Activity className="w-4 h-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-secondary">{analyticsData.riskScore}</div>
            <Badge variant="secondary" className="mt-2 text-xs">
              Moderate Risk
            </Badge>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Risk Dept</CardTitle>
            <BarChart3 className="w-4 h-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive">{maxRiskDept.name}</div>
            <Badge variant="destructive" className="mt-2 text-xs">
              Risk: {maxRiskDept.risk}
            </Badge>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Department Analysis */}
        <Card className="animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              Department Analysis
              <Badge className="bg-primary text-primary-foreground font-mono">
                {analyticsData.departments.length} Departments
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analyticsData.departments.map((dept, index) => {
                const maxSessions = Math.max(...analyticsData.departments.map(d => d.sessions));
                const sessionPercentage = (dept.sessions / maxSessions) * 100;
                const riskLevel = dept.risk >= 20 ? 'High' : dept.risk >= 10 ? 'Medium' : 'Low';
                const riskColor = dept.risk >= 20 ? 'destructive' : dept.risk >= 10 ? 'secondary' : 'outline';
                
                return (
                  <div key={dept.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-card-foreground">{dept.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-mono text-primary">{dept.sessions} sessions</span>
                        <Badge variant={riskColor as any} className="text-xs">
                          {riskLevel}
                        </Badge>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Sessions</span>
                        <span>Risk: {dept.risk}</span>
                      </div>
                      <div className="flex gap-2">
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-primary to-chart-1 rounded-full transition-all duration-1000 animate-glow"
                            style={{ 
                              width: `${sessionPercentage}%`,
                              animationDelay: `${index * 200}ms`
                            }}
                            data-testid={`chart-sessions-${dept.name.toLowerCase()}`}
                          />
                        </div>
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-1000 ${
                              dept.risk >= 20 ? 'bg-destructive' : 
                              dept.risk >= 10 ? 'bg-secondary' : 'bg-primary'
                            }`}
                            style={{ 
                              width: `${(dept.risk / 25) * 100}%`,
                              animationDelay: `${index * 200}ms`
                            }}
                            data-testid={`chart-risk-${dept.name.toLowerCase()}`}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Threat Analysis */}
        <Card className="animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Threat Analysis
              <Badge className="bg-primary text-primary-foreground font-mono">
                Top 5 Threats
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analyticsData.topThreats.map((threat, index) => {
                const isIncreasing = threat.trend > 0;
                const TrendIcon = isIncreasing ? TrendingUp : TrendingDown;
                const trendColor = isIncreasing ? 'text-destructive' : 'text-primary';
                
                return (
                  <div 
                    key={threat.type} 
                    className="flex items-center justify-between p-3 bg-card border border-card-border rounded-lg hover-elevate animate-slide-up"
                    style={{ animationDelay: `${index * 100}ms` }}
                    data-testid={`threat-${threat.type.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-card-foreground">{threat.type}</span>
                        <Badge 
                          variant={threat.count >= 10 ? 'destructive' : threat.count >= 5 ? 'secondary' : 'outline'} 
                          className="text-xs"
                        >
                          {threat.count} incidents
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <TrendIcon className={`w-3 h-3 ${trendColor}`} />
                          <span className={`text-xs font-mono ${trendColor}`}>
                            {Math.abs(threat.trend)}% {isIncreasing ? 'increase' : 'decrease'}
                          </span>
                        </div>
                        <span className="text-xs text-muted-foreground">vs last period</span>
                      </div>
                    </div>
                    <div className="w-12 h-8">
                      <div className="h-full flex items-end justify-center">
                        <div 
                          className={`w-2 rounded-t transition-all duration-1000 ${
                            threat.count >= 10 ? 'bg-destructive' : 
                            threat.count >= 5 ? 'bg-secondary' : 'bg-primary'
                          }`}
                          style={{ 
                            height: `${(threat.count / 15) * 100}%`,
                            animationDelay: `${index * 150}ms`
                          }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Device Distribution */}
      <Card className="animate-fade-in">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            Device Distribution
            <Badge className="bg-primary text-primary-foreground font-mono">
              {analyticsData.deviceDistribution.reduce((sum, device) => sum + device.count, 0)} Devices
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {analyticsData.deviceDistribution.map((device, index) => (
              <div 
                key={device.type}
                className="p-4 bg-card border border-card-border rounded-lg hover-elevate animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
                data-testid={`device-${device.type.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase()}`}
              >
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold font-mono text-primary">{device.count}</div>
                  <div className="text-sm font-medium text-card-foreground">{device.type}</div>
                  <Badge variant="outline" className="text-xs">
                    {device.percentage}%
                  </Badge>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-primary to-chart-1 rounded-full transition-all duration-1000"
                      style={{ 
                        width: `${device.percentage}%`,
                        animationDelay: `${index * 200}ms`
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}