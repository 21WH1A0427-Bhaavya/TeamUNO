import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, Shield, Bell, Users, Database, Save, AlertTriangle, Eye } from 'lucide-react';

interface SecurityPolicy {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  severity: 'Low' | 'Medium' | 'High';
}

interface NotificationSettings {
  email: boolean;
  push: boolean;
  sms: boolean;
  threshold: 'Low' | 'Medium' | 'High';
}

export default function Settings() {
  const [securityPolicies, setSecurityPolicies] = useState<SecurityPolicy[]>([
    {
      id: '1',
      name: 'Mass Download Detection',
      description: 'Alert when users download multiple files in a short time',
      enabled: true,
      severity: 'High'
    },
    {
      id: '2',
      name: 'MFA Enforcement',
      description: 'Require multi-factor authentication for privileged actions',
      enabled: true,
      severity: 'High'
    },
    {
      id: '3',
      name: 'Unusual Hours Access',
      description: 'Monitor access outside standard business hours',
      enabled: true,
      severity: 'Medium'
    },
    {
      id: '4',
      name: 'Geographic Anomaly Detection',
      description: 'Alert on logins from unusual geographic locations',
      enabled: false,
      severity: 'Medium'
    },
    {
      id: '5',
      name: 'Failed Login Monitoring',
      description: 'Track and alert on multiple failed login attempts',
      enabled: true,
      severity: 'High'
    }
  ]);

  const [notifications, setNotifications] = useState<NotificationSettings>({
    email: true,
    push: true,
    sms: false,
    threshold: 'Medium'
  });

  const [systemSettings, setSystemSettings] = useState({
    sessionTimeout: '30',
    maxFailedLogins: '5',
    passwordPolicy: 'strict',
    dataRetention: '90',
    logLevel: 'info'
  });

  const [userManagement, setUserManagement] = useState({
    autoProvision: false,
    requireApproval: true,
    defaultRole: 'user',
    sessionLimit: '3'
  });

  const togglePolicy = (policyId: string) => {
    setSecurityPolicies(prev => prev.map(policy => 
      policy.id === policyId ? { ...policy, enabled: !policy.enabled } : policy
    ));
  };

  const updatePolicySeverity = (policyId: string, severity: 'Low' | 'Medium' | 'High') => {
    setSecurityPolicies(prev => prev.map(policy => 
      policy.id === policyId ? { ...policy, severity } : policy
    ));
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
      default: return 'outline';
    }
  };

  const saveSettings = (category: string) => {
    console.log(`Saving ${category} settings`);
    // Here you would typically make an API call to save settings
  };

  const enabledPolicies = securityPolicies.filter(p => p.enabled).length;
  const highSeverityPolicies = securityPolicies.filter(p => p.enabled && p.severity === 'High').length;

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-mono">Settings</h1>
          <p className="text-muted-foreground">Configure system security and monitoring preferences</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge className="bg-primary text-primary-foreground font-mono">
            {enabledPolicies} Active Policies
          </Badge>
          <Badge variant="destructive" className="font-mono">
            {highSeverityPolicies} High Priority
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="security" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="security" data-testid="tab-security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="w-4 h-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="users" data-testid="tab-users">
            <Users className="w-4 h-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="system" data-testid="tab-system">
            <Database className="w-4 h-4 mr-2" />
            System
          </TabsTrigger>
          <TabsTrigger value="monitoring" data-testid="tab-monitoring">
            <Eye className="w-4 h-4 mr-2" />
            Monitoring
          </TabsTrigger>
        </TabsList>

        {/* Security Policies Tab */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Security Policies
                <Badge className="bg-primary text-primary-foreground font-mono">
                  {securityPolicies.length} Policies
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {securityPolicies.map((policy, index) => (
                <div 
                  key={policy.id}
                  className="flex items-center justify-between p-4 bg-card border border-card-border rounded-lg hover-elevate animate-slide-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                  data-testid={`policy-${policy.id}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-card-foreground">{policy.name}</h3>
                      <Badge variant={getSeverityColor(policy.severity) as any} className="text-xs">
                        {policy.severity}
                      </Badge>
                      {policy.enabled && (
                        <Badge className="text-xs bg-primary/20 text-primary border-primary/30">
                          Active
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{policy.description}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Select 
                      value={policy.severity} 
                      onValueChange={(value: 'Low' | 'Medium' | 'High') => updatePolicySeverity(policy.id, value)}
                    >
                      <SelectTrigger className="w-24" data-testid={`select-severity-${policy.id}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <Switch 
                      checked={policy.enabled} 
                      onCheckedChange={() => togglePolicy(policy.id)}
                      data-testid={`switch-policy-${policy.id}`}
                    />
                  </div>
                </div>
              ))}
              <div className="flex justify-end">
                <Button onClick={() => saveSettings('security')} className="flex items-center gap-2" data-testid="button-save-security">
                  <Save className="w-4 h-4" />
                  Save Security Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-primary" />
                  Notification Channels
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications" className="text-sm font-medium">Email Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive alerts via email</p>
                  </div>
                  <Switch 
                    id="email-notifications"
                    checked={notifications.email}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, email: checked }))}
                    data-testid="switch-email-notifications"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="push-notifications" className="text-sm font-medium">Push Notifications</Label>
                    <p className="text-xs text-muted-foreground">Browser push notifications</p>
                  </div>
                  <Switch 
                    id="push-notifications"
                    checked={notifications.push}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, push: checked }))}
                    data-testid="switch-push-notifications"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sms-notifications" className="text-sm font-medium">SMS Notifications</Label>
                    <p className="text-xs text-muted-foreground">Critical alerts via SMS</p>
                  </div>
                  <Switch 
                    id="sms-notifications"
                    checked={notifications.sms}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, sms: checked }))}
                    data-testid="switch-sms-notifications"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-primary" />
                  Alert Thresholds
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="threshold-select" className="text-sm font-medium">Minimum Alert Severity</Label>
                  <Select 
                    value={notifications.threshold} 
                    onValueChange={(value: 'Low' | 'Medium' | 'High') => setNotifications(prev => ({ ...prev, threshold: value }))}
                  >
                    <SelectTrigger data-testid="select-notification-threshold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">All Alerts (Low+)</SelectItem>
                      <SelectItem value="Medium">Medium & High Only</SelectItem>
                      <SelectItem value="High">High Priority Only</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    You will receive notifications for alerts at or above this severity level
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => saveSettings('notifications')} className="flex items-center gap-2" data-testid="button-save-notifications">
              <Save className="w-4 h-4" />
              Save Notification Settings
            </Button>
          </div>
        </TabsContent>

        {/* User Management Tab */}
        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                User Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Auto-provision new users</Label>
                      <p className="text-xs text-muted-foreground">Automatically create accounts for new users</p>
                    </div>
                    <Switch 
                      checked={userManagement.autoProvision}
                      onCheckedChange={(checked) => setUserManagement(prev => ({ ...prev, autoProvision: checked }))}
                      data-testid="switch-auto-provision"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Require approval</Label>
                      <p className="text-xs text-muted-foreground">New accounts need admin approval</p>
                    </div>
                    <Switch 
                      checked={userManagement.requireApproval}
                      onCheckedChange={(checked) => setUserManagement(prev => ({ ...prev, requireApproval: checked }))}
                      data-testid="switch-require-approval"
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="default-role" className="text-sm font-medium">Default Role</Label>
                    <Select 
                      value={userManagement.defaultRole} 
                      onValueChange={(value) => setUserManagement(prev => ({ ...prev, defaultRole: value }))}
                    >
                      <SelectTrigger data-testid="select-default-role">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="developer">Developer</SelectItem>
                        <SelectItem value="admin">Administrator</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="session-limit" className="text-sm font-medium">Max concurrent sessions</Label>
                    <Input 
                      id="session-limit"
                      type="number" 
                      value={userManagement.sessionLimit}
                      onChange={(e) => setUserManagement(prev => ({ ...prev, sessionLimit: e.target.value }))}
                      className="w-full"
                      data-testid="input-session-limit"
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button onClick={() => saveSettings('users')} className="flex items-center gap-2" data-testid="button-save-users">
                  <Save className="w-4 h-4" />
                  Save User Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Configuration Tab */}
        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                System Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="session-timeout" className="text-sm font-medium">Session Timeout (minutes)</Label>
                    <Input 
                      id="session-timeout"
                      type="number" 
                      value={systemSettings.sessionTimeout}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, sessionTimeout: e.target.value }))}
                      data-testid="input-session-timeout"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max-failed-logins" className="text-sm font-medium">Max Failed Login Attempts</Label>
                    <Input 
                      id="max-failed-logins"
                      type="number" 
                      value={systemSettings.maxFailedLogins}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, maxFailedLogins: e.target.value }))}
                      data-testid="input-max-failed-logins"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password-policy" className="text-sm font-medium">Password Policy</Label>
                    <Select 
                      value={systemSettings.passwordPolicy} 
                      onValueChange={(value) => setSystemSettings(prev => ({ ...prev, passwordPolicy: value }))}
                    >
                      <SelectTrigger data-testid="select-password-policy">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic (8 characters)</SelectItem>
                        <SelectItem value="standard">Standard (8+ chars, numbers)</SelectItem>
                        <SelectItem value="strict">Strict (12+ chars, mixed case, symbols)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="data-retention" className="text-sm font-medium">Data Retention (days)</Label>
                    <Input 
                      id="data-retention"
                      type="number" 
                      value={systemSettings.dataRetention}
                      onChange={(e) => setSystemSettings(prev => ({ ...prev, dataRetention: e.target.value }))}
                      data-testid="input-data-retention"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="log-level" className="text-sm font-medium">Log Level</Label>
                    <Select 
                      value={systemSettings.logLevel} 
                      onValueChange={(value) => setSystemSettings(prev => ({ ...prev, logLevel: value }))}
                    >
                      <SelectTrigger data-testid="select-log-level">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="error">Error Only</SelectItem>
                        <SelectItem value="warn">Warning & Error</SelectItem>
                        <SelectItem value="info">Info, Warning & Error</SelectItem>
                        <SelectItem value="debug">All (Debug Mode)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-6">
                <Button onClick={() => saveSettings('system')} className="flex items-center gap-2" data-testid="button-save-system">
                  <Save className="w-4 h-4" />
                  Save System Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Monitoring Tab */}
        <TabsContent value="monitoring">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-primary" />
                Monitoring Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 bg-muted/20 rounded-lg border border-primary/20">
                  <h3 className="font-semibold text-card-foreground mb-2">Real-time Monitoring</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Configure how the system monitors user activities and detects anomalies in real-time.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Network Traffic Monitoring</span>
                      <Switch defaultChecked data-testid="switch-network-monitoring" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">File Access Tracking</span>
                      <Switch defaultChecked data-testid="switch-file-tracking" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Application Usage Monitoring</span>
                      <Switch defaultChecked data-testid="switch-app-monitoring" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Geographic Location Tracking</span>
                      <Switch defaultChecked data-testid="switch-geo-tracking" />
                    </div>
                  </div>
                </div>
                
                <div className="p-4 bg-muted/20 rounded-lg border border-secondary/20">
                  <h3 className="font-semibold text-card-foreground mb-2">Anomaly Detection</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    AI-powered anomaly detection using Isolation Forest and Autoencoder methods.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Sensitivity Level</Label>
                      <Select defaultValue="medium">
                        <SelectTrigger data-testid="select-anomaly-sensitivity">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low (Fewer false positives)</SelectItem>
                          <SelectItem value="medium">Medium (Balanced)</SelectItem>
                          <SelectItem value="high">High (More sensitive)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Model Update Frequency</Label>
                      <Select defaultValue="daily">
                        <SelectTrigger data-testid="select-model-update">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="realtime">Real-time</SelectItem>
                          <SelectItem value="hourly">Hourly</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-6">
                <Button onClick={() => saveSettings('monitoring')} className="flex items-center gap-2" data-testid="button-save-monitoring">
                  <Save className="w-4 h-4" />
                  Save Monitoring Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}