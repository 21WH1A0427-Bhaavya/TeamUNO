import MetricsCard from '../components/MetricsCard';
import AlertPanel from '../components/AlertPanel';
import ActivityTable from '../components/ActivityTable';
import DataChart from '../components/DataChart';
import { Users, AlertTriangle, Shield, Activity } from 'lucide-react';
import { useState, useEffect } from 'react';

// Todo: remove mock data when integrating with real backend
const mockAlerts = [
  {
    id: '1',
    type: 'mass_download',
    user: 'user_00080',
    message: 'Unusual mass download activity detected from Sales department',
    priority: 'High' as const,
    timestamp: '08:11:00'
  },
  {
    id: '2', 
    type: 'no_mfa_privileged_action',
    user: 'user_00085',
    message: 'Privileged action performed without MFA verification',
    priority: 'Medium' as const,
    timestamp: '08:27:00'
  },
  {
    id: '3',
    type: 'suspicious_app_usage',
    user: 'user_00030',
    message: 'Suspicious application usage pattern detected',
    priority: 'Low' as const,
    timestamp: '08:34:00'
  }
];

const mockActivities = [
  {
    user_id: 'user_00080',
    department: 'Sales',
    session_minutes: 37,
    device_type: 'Windows-PC',
    location_country: 'Singapore',
    anomaly_score: 0.344,
    is_anomaly: true,
    anomaly_type: 'mass_download',
    risk_score: 12,
    timestamp: '08:11:00'
  },
  {
    user_id: 'user_00085',
    department: 'IT',
    session_minutes: 95,
    device_type: 'Windows-PC',
    location_country: 'India',
    anomaly_score: 0.249,
    is_anomaly: true,
    anomaly_type: 'no_mfa_privileged_action',
    risk_score: 16,
    timestamp: '08:27:00'
  },
  {
    user_id: 'user_00030',
    department: 'HR',
    session_minutes: 17,
    device_type: 'Windows-PC',
    location_country: 'India',
    anomaly_score: 0.128,
    is_anomaly: true,
    anomaly_type: 'suspicious_app_usage',
    risk_score: 5,
    timestamp: '08:34:00'
  },
  {
    user_id: 'user_00051',
    department: 'Finance',
    session_minutes: 33,
    device_type: 'MacBook',
    location_country: 'Singapore',
    anomaly_score: 0.202,
    is_anomaly: false,
    risk_score: 13,
    timestamp: '08:35:00'
  }
];

const departmentRiskData = [
  { label: 'Sales', value: 23 },
  { label: 'IT', value: 18 },
  { label: 'HR', value: 15 },
  { label: 'Finance', value: 12 },
  { label: 'R&D', value: 8 }
];

const anomalyTypeData = [
  { label: 'Mass Download', value: 12 },
  { label: 'No MFA', value: 8 },
  { label: 'Suspicious App Usage', value: 6 },
  { label: 'Unusual Hours', value: 4 },
  { label: 'Geo Risk', value: 3 }
];

export default function DashboardHome() {
  const [metrics, setMetrics] = useState({
    activeSessions: 147,
    anomaliesDetected: 23,
    riskScore: "Medium",
    systemHealth: "98.5%"
  });

  // Todo: replace with real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        activeSessions: prev.activeSessions + Math.floor(Math.random() * 3) - 1,
        anomaliesDetected: Math.max(0, prev.anomaliesDetected + Math.floor(Math.random() * 3) - 1)
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6 space-y-6">
      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricsCard
          title="Active Sessions"
          value={metrics.activeSessions}
          trend={{ value: "12%", isUp: true }}
          icon={Users}
        />
        <MetricsCard
          title="Anomalies Detected"
          value={metrics.anomaliesDetected}
          trend={{ value: "5%", isUp: true }}
          icon={AlertTriangle}
          alert
        />
        <MetricsCard
          title="Risk Score"
          value={metrics.riskScore}
          icon={Shield}
        />
        <MetricsCard
          title="System Health"
          value={metrics.systemHealth}
          trend={{ value: "0.2%", isUp: false }}
          icon={Activity}
        />
      </div>

      {/* Charts and Alerts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DataChart 
              title="Risk by Department" 
              data={departmentRiskData}
            />
            <DataChart 
              title="Anomaly Types" 
              data={anomalyTypeData}
            />
          </div>
        </div>
        <AlertPanel alerts={mockAlerts} />
      </div>

      {/* Activity Table */}
      <ActivityTable activities={mockActivities} />
    </div>
  );
}