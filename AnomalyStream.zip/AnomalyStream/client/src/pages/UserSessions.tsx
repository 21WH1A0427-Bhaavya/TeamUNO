import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Search, Filter, Eye, X, AlertTriangle, Laptop, Smartphone, Server, Clock, MapPin } from 'lucide-react';

interface UserSession {
  user_id: string;
  department: string;
  privilege_level: string;
  session_id: string;
  login_time: string;
  logout_time?: string;
  session_minutes: number;
  device_type: string;
  location_country: string;
  ip_address: string;
  is_active: boolean;
  risk_score: number;
  is_anomaly: boolean;
  anomaly_type?: string;
  files_accessed: number;
  bytes_downloaded: number;
  app_used: string;
}

export default function UserSessions() {
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<UserSession[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Initialize with data from the CSV
  useEffect(() => {
    const initialSessions: UserSession[] = [
      {
        user_id: 'user_00080',
        department: 'Sales',
        privilege_level: 'user',
        session_id: 'user_00080-2025-05-30-1-28be92db',
        login_time: '08:11:00',
        session_minutes: 37,
        device_type: 'Windows-PC',
        location_country: 'Singapore',
        ip_address: '101.198.24.110',
        is_active: true,
        risk_score: 12,
        is_anomaly: true,
        anomaly_type: 'mass_download',
        files_accessed: 7,
        bytes_downloaded: 315164,
        app_used: 'sql_client'
      },
      {
        user_id: 'user_00085',
        department: 'IT',
        privilege_level: 'user',
        session_id: 'user_00085-2025-05-30-2-8e3a8500',
        login_time: '08:27:00',
        session_minutes: 95,
        device_type: 'Windows-PC',
        location_country: 'India',
        ip_address: '153.254.118.132',
        is_active: true,
        risk_score: 16,
        is_anomaly: true,
        anomaly_type: 'no_mfa_privileged_action',
        files_accessed: 7,
        bytes_downloaded: 427581,
        app_used: 'file_explorer'
      },
      {
        user_id: 'user_00030',
        department: 'HR',
        privilege_level: 'user',
        session_id: 'user_00030-2025-05-30-1-3e7b75b8',
        login_time: '08:34:00',
        session_minutes: 17,
        device_type: 'Windows-PC',
        location_country: 'India',
        ip_address: '26.210.184.27',
        is_active: false,
        risk_score: 5,
        is_anomaly: true,
        anomaly_type: 'suspicious_app_usage',
        files_accessed: 6,
        bytes_downloaded: 76472,
        app_used: 'email'
      },
      {
        user_id: 'user_00051',
        department: 'Finance',
        privilege_level: 'user',
        session_id: 'user_00051-2025-05-30-0-e7036120',
        login_time: '08:35:00',
        session_minutes: 33,
        device_type: 'MacBook',
        location_country: 'Singapore',
        ip_address: '160.251.26.201',
        is_active: true,
        risk_score: 13,
        is_anomaly: false,
        files_accessed: 2,
        bytes_downloaded: 418065,
        app_used: 'email'
      },
      {
        user_id: 'user_00004',
        department: 'IT',
        privilege_level: 'user',
        session_id: 'user_00004-2025-05-30-0-c7836457',
        login_time: '08:42:00',
        session_minutes: 101,
        device_type: 'Windows-PC',
        location_country: 'Singapore',
        ip_address: '179.139.55.180',
        is_active: true,
        risk_score: 5,
        is_anomaly: false,
        files_accessed: 4,
        bytes_downloaded: 133230,
        app_used: 'file_explorer'
      }
    ];
    setSessions(initialSessions);
    setFilteredSessions(initialSessions);
  }, []);

  // Filter sessions based on search and filters
  useEffect(() => {
    let filtered = sessions;

    if (searchTerm) {
      filtered = filtered.filter(session => 
        session.user_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.location_country.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (departmentFilter !== 'all') {
      filtered = filtered.filter(session => session.department === departmentFilter);
    }

    if (statusFilter === 'active') {
      filtered = filtered.filter(session => session.is_active);
    } else if (statusFilter === 'inactive') {
      filtered = filtered.filter(session => !session.is_active);
    } else if (statusFilter === 'anomaly') {
      filtered = filtered.filter(session => session.is_anomaly);
    }

    setFilteredSessions(filtered);
  }, [sessions, searchTerm, departmentFilter, statusFilter]);

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'Windows-PC': case 'MacBook': return Laptop;
      case 'Mobile': return Smartphone;
      case 'Linux-Server': case 'VDI': return Server;
      default: return Laptop;
    }
  };

  const getRiskColor = (score: number) => {
    if (score >= 15) return 'destructive';
    if (score >= 10) return 'secondary';
    return 'outline';
  };

  const terminateSession = (sessionId: string) => {
    setSessions(prev => prev.map(session => 
      session.session_id === sessionId 
        ? { ...session, is_active: false, logout_time: new Date().toLocaleTimeString() }
        : session
    ));
  };

  const activeCount = sessions.filter(s => s.is_active).length;
  const anomalyCount = sessions.filter(s => s.is_anomaly).length;
  const departments = Array.from(new Set(sessions.map(s => s.department)));

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground font-mono">User Sessions</h1>
          <p className="text-muted-foreground">Manage and monitor active user sessions</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge className="bg-primary text-primary-foreground font-mono">
            {activeCount} Active
          </Badge>
          <Badge variant="destructive" className="font-mono">
            {anomalyCount} Anomalies
          </Badge>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search users, departments, locations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-session-search"
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-48" data-testid="select-department-filter">
                <SelectValue placeholder="All Departments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32" data-testid="select-status-filter">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="anomaly">Anomalies</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Sessions Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            User Sessions
            <Badge className="bg-primary text-primary-foreground font-mono">
              {filteredSessions.length} Results
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredSessions.map((session, index) => {
              const DeviceIcon = getDeviceIcon(session.device_type);
              return (
                <div
                  key={session.session_id}
                  className={`p-4 border border-card-border rounded-lg hover-elevate animate-slide-up transition-all ${
                    session.is_anomaly ? 'border-destructive/50 bg-destructive/5' : ''
                  }`}
                  style={{ animationDelay: `${index * 50}ms` }}
                  data-testid={`session-${session.user_id}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-4">
                      {/* User Info */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          {session.is_anomaly && (
                            <AlertTriangle className="w-4 h-4 text-destructive" />
                          )}
                          <span className="font-mono font-semibold text-card-foreground">
                            {session.user_id}
                          </span>
                          <div className={`w-2 h-2 rounded-full ${
                            session.is_active ? 'bg-primary animate-pulse' : 'bg-muted'
                          }`}></div>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          <Badge variant="outline" className="text-xs">
                            {session.department}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {session.privilege_level}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground font-mono">
                          {session.session_id.split('-').pop()}
                        </div>
                      </div>

                      {/* Device & Location */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <DeviceIcon className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-card-foreground">{session.device_type}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-muted-foreground" />
                          <span className="text-sm text-card-foreground">{session.location_country}</span>
                        </div>
                        <div className="text-xs font-mono text-muted-foreground">
                          {session.ip_address}
                        </div>
                      </div>

                      {/* Session Details */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-muted-foreground" />
                          <span className="text-sm text-card-foreground">
                            {session.session_minutes}m
                          </span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Login: {session.login_time}
                        </div>
                        <div className="text-xs text-primary font-mono">
                          Files: {session.files_accessed} • {(session.bytes_downloaded / 1024).toFixed(0)}KB
                        </div>
                        <div className="text-xs text-muted-foreground">
                          App: {session.app_used}
                        </div>
                      </div>

                      {/* Risk & Status */}
                      <div className="space-y-2">
                        <Badge variant={getRiskColor(session.risk_score) as any} className="font-mono text-xs">
                          Risk: {session.risk_score}
                        </Badge>
                        {session.is_anomaly && session.anomaly_type && (
                          <Badge variant="destructive" className="text-xs">
                            {session.anomaly_type.replace('_', ' ')}
                          </Badge>
                        )}
                        <div className="text-xs text-muted-foreground">
                          Status: {session.is_active ? 'Active' : 'Ended'}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" className="w-8 h-8" data-testid={`button-view-${session.user_id}`}>
                        <Eye className="w-4 h-4" />
                      </Button>
                      {session.is_active && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 text-destructive hover:text-destructive"
                          onClick={() => terminateSession(session.session_id)}
                          data-testid={`button-terminate-${session.user_id}`}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            {filteredSessions.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No sessions match your current filters.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}